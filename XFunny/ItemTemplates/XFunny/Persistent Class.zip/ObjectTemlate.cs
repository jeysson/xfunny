﻿using System;
using XFunny.QAccess;
using XFunny.QConnecting;

namespace $rootnamespace$
{
    class $safeitemname$: QObjectBase
    {
        #region Fields

        #endregion

        #region Properties

        #endregion

        #region NonPersistent Fields

        #endregion

        #region Nonpersistent Properties

        #endregion

        #region Overrides

        #endregion

        #region constructos
        /// <summary>
        /// Construtor
        /// </summary>
        public $safeitemname$()
        {
            
        }
        /// <summary>
        /// Construtor
        /// </summary>
        /// <param name="pConnect">Conexão</param>
        public $safeitemname$(QConnect pConnect)
            : base(pConnect)
        {

        }
        #endregion
    }
}
